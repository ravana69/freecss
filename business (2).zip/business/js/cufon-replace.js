Cufon.replace('.menu a,#menu a, h1, h2', { fontFamily: 'Amaranth', hover:true });

