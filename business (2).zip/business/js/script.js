$(document).ready(function() {
	// initiate tool tip
	// basic usage  
	$('.normaltip').aToolTip();  
});