$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.menu_nav').css({"border-top-left-radius": "16px", "-moz-border-radius-topleft":"16px", "-webkit-border-top-left-radius":"16px", "border-top-right-radius": "16px", "-moz-border-radius-topright":"16px", "-webkit-border-top-right-radius":"16px"});
	// end radius Box
	 
});	