Template Name: AppStation
Template URI: http://www.wpfreeware.com/appstation-free-bootstrap-html5-app-landing-page-theme/
Author: WpFreeware
Author URI: http://www.wpfreeware.com
Description: App Landing Bootstrap HTML5/CSS3 One Page Template
Version: 1.0 
License: GPL
License URI: http://www.gnu.org/licenses/gpl-3.0.html




---------------------------------------------
Find more great resources @ WpFreeware.com
Sincerely,
The WpFreeware Team.
---------------------------------------------
http://www.wpfreeware.com
PS. Those terms might change as we update our license on our website, 
please be sure to check the latest license terms on our website to avoid any misuse of our resources.

Thank you!