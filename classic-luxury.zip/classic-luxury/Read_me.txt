
Classic Luxury is a high quality, clean and simple CSS-based template with three custom pages created by CssTemplateHeaven.

It is clean and has a lot of whitespace and nice typography. The code is well-organized and uses standards-based HTML and CSS.

Classic Luxury is great for portfolios and personal photo sites, and can be converted easily to a CMS theme as needed (such as Drupal or WordPress).

You may use this template in any projects you like (both personal/non-profit and commercial), but you cannot resell this pack�s source files.