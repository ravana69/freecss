Cufon.replace('#menu a, h2, .dropcap_1, .button', { fontFamily: 'Butter', hover:true });

