$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.menu_nav ul li a').css({"border-radius": "4px", "-moz-border-radius":"4px", "-webkit-border-radius":"4px"});
	// end radius Box
	 
});	