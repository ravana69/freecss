Astral 1.0 by HTML5 Up!
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

This is Astral, a fully responsive HTML5 site template designed by AJ/n33 and released
for free by HTML5 Up! It features a flat, minimalistic design, a fully animated interface
(with noscript fallbacks), and styling for all basic page elements (including blockquotes, 
tables and lists).

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

- AJ (@n33co)

PS: This site template is fully responsive, meaning it'll look great on desktop 
(widescreen and standard), tablet and mobile device displays. To see what this looks
like, just narrow down your browser window and hit "reload".

Credits:
	
	Homepage Photo
		fotogrph (http://fotogrph.com)
	
	Icon Font:
		Kazuyuki Motoyama (http://kudakurage.com/ligature_symbols/)
	
	Work Samples:
		Kim Petersen (http://flypixel.com/kimpetersend1)
		Juicy Graphics (http://flypixel.com/juicygraphics)
		Victor Erixon (http://flypixel.com/victorerixon)
		Alex Vanderzon (http://flypixel.com/vanderzon)
		Maki Myers (http://flypixel.com/pixelqraft)
		Jonathan Shariat (http://flypixel.com/jonshariat)
		Oliver Long (http://flypixel.com/pixelfreebies)
		Asif Aleem (http://flypixel.com/asifaleem)
		AJ (http://flypixel.com/n33)