Cufon.replace('h2, #contacts-form a', { fontFamily: 'OrigGarmnd BT', hover:true });
Cufon.replace('nav ul li a', { fontFamily: 'OrigGarmnd BT', textShadow:'1px 1px #fff', hover:true });