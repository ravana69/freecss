function ShowHide(id){object = document.getElementById(id);if(object.style.display=="none"){object.style.display='';}else{object.style.display='none';}}
