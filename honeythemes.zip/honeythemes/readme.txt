/*------------------------------------------------------------------------
# HoneyThemes - July 2010
# ------------------------------------------------------------------------
# Copyright (C) 2010 instantShift. All Rights Reserved.
# @license - HoneyThemes Layout is available under the terms of the GNU General Public License.
# Author: InstantShift.com
# Developer: RapidxHTML.com
# Websites:  http://www.instantshift.com
-------------------------------------------------------------------------*/

"HoneyThemes" is a free, personal theme-shop design, with a very clean and elegant style. Along with the great design, we�ve also included all of the other mordern qualities in this theme layout to make your stay comfortable. 


Features ::
---------------
1. Modern and beautiful web typeface.
2. Tableless design and 100% CSS-based layout.
3. 2 columns of fixed width.
4. Cufon font replacement enabled.
5. XHTML 1.0 Strict valid.
6. CSS 2.1 valid.
7. Delivered with source .PSD file.
8. Well-commented CSS and theme PHP files for flexible customization.
9. Multi-browser compatibility. Tested under modern w3c compliant browsers. Firefox 3 , Safari 2 and IE7.


Disclaimer ::
-------------
"HoneyThemes" is a free theme Layout release and we thus release it �as is�. We & Rapidxhtml.com will not be offering any support to users of this theme layout. If you would like some assistance with "HoneyThemes" and you�d like to tap into the collective knowledge of the instantShift community


Agreements ::
-------------
By downloading this theme layout, under the terms of the GNU General Public License, it is vital that you understood the following terms and conditions:

1. A link back must be included in the footer or simply just don�t remove the credits from footer.
2. You can use them on as many domain names as you wish.
3. You may use them for your clients� projects / websites. Number of projects is not limited.
4. You may not claim intellectual and exclusive ownership to any of the themes layout.
5. You may not sub-license the original themes layout and their individual files to and with anyone else, unless a specific license within the theme states otherwise.
6. You may modify them. However, you may not modify and then resell, unless the modified versions are drastically different from the originals.
7. We reserve the right to refuse, cancel, or suspend service at our sole discretion and the right to change or modify these terms with no prior notice.
8. No support will be provided for any free theme by instantShift.


Credits ::
---------------
All the icons which is used in "HoneyThemes" is free for use and Designed by our fellow design community. All the "Latest Themes" designs and their creatives designed by following designers.
FroggySpace: http://www.mybrainart.com/home.html#web
Velkommen: http://vision66.deviantart.com/art/Wich-one-do-YOU-like-best-128970509
Inspira: http://alxdesign.deviantart.com/art/Inspira-135399954 


Thank You,
Brought to you by instanShift (www.instantshift.com) and developed by RapidxHTML (www.rapidxhtml.com).
For any other query contact us at contact@instantshift.com
