$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.menu_nav').css({"border-top-left-radius": "16px", "-moz-border-radius-topleft":"16px", "-webkit-border-top-left-radius":"16px", "border-top-right-radius": "16px", "-moz-border-radius-topright":"16px", "-webkit-border-top-right-radius":"16px"});
	$('.fbg_resize').css({"border-bottom-left-radius": "16px", "-moz-border-radius-bottomleft":"16px", "-webkit-border-bottom-left-radius":"16px", "border-bottom-right-radius": "16px", "-moz-border-radius-bottomright":"16px", "-webkit-border-bottom-right-radius":"16px"});
	// end radius Box
	 
});	