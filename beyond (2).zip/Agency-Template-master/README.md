# Beyond Agency- Template
An HTML5 and CSS3 Template for Creatives

Hi There!
Thank you for checking out my HTML5 templates.

Features:-
  - Fully responsive
  - Full width portfolio grid
  - Full screen header
  - Animated Scrolling for links
  - Includes all SASS files and map files
  - Uses Lemonade.scss as a basic, lightweight grid framework (http://lemonade.im/)
  - Jquery mobile navigation
  - CSS animations

If you liked this template please share it with your friends or on social media!

Thanks!
