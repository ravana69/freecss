- - - FREE TEMPLATES FROM http://www.firebubble.co.uk - - -

Thank-you for downloading our free template.

This template has been designed to be as Search Engine Friendly as possible, you can find help in the code in closed off comments. 

e.g. <!--EDIT HERE!-->

Now that you have downloaded the files, you are free to use at your leisure.

Please do the following:

 - Do not delete or modify the small credit link at the bottom of the template.
 
 - Please do not upload this free template to another web-site, claiming that you or your company designed it.
 
 
 For support with the template, please contact us via our web-site http://www.firebubble.co.uk/ 