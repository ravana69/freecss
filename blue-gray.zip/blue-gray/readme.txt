Blue Gray Template First Light Web Design 2007.

Thanks for downloading one of my designs.
 
Contact: terry@firstlightwebdesign.com
--------------------------------------------------------------------------------------------
License / Terms of Use

Your use of the template signifies both acknowledgment and agreement with the following:

This work is licensed under the Creative Commons Attribution 2.5 License. To view a copy of this license, visit http://creativecommons.org/licenses/by/2.5/ or send a letter to Creative Commons, 543 Howard Street, 5th Floor, San Francisco, California, 94105, USA. You may use this template freely for both personal and commercial for-profit web sites. Basically the only requirement is to leave the credit "Design by First Light" with the hyper link in the footer of the page.    

This template is provided "as is" and without warranty either expressed or implied. While every effort is made to create useful, and technically sound designs, you are solely responsible for evaluating the template's content, accuracy, merchantability, or quality. The user agrees the designer of the template shall not be liable for any alleged
damages caused by the use of the template. You are solely responsible for adding your own content. The template is made available without any promise of technical support.
--------------------------------------------------------------------------------------------
Tips and Info
     
I supplied a blank header background (png) so you can render your logo, site name, and slogan over it. The main thing you need to keep in mind when you upload the files to your server is to keep everything in the same folder. You should have a main directory usually "public" with all the html pages, the css file, and a folder containing the images (structured just as it is in the folder you downloaded).

I have included a simplified single column and two column sub-page layout.

Important note: I have started to use conditional comments instead of the traditional hacks (* html, etc.) to accommodate Internet Explorer's infamous flaws. That's why you have the extra style sheet named "iefixes". Only Internet Explorer will see that particular style sheet but it is nonetheless necessary. When I create new designs I try to provide Internet Explorer browser support back to at least version 5.5.        

If you get really stuck on something or need some help, contact me and I will do my best to help you out.

Good luck with your website.