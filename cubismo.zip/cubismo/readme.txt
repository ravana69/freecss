Thank you for downloading my work, template Cubsimo.

Template is released under Creative Commons Attribution 2.5 License. You are free to use and modify theme, but you must include the provided link in the footer. Thx.

There is also a Word Press version. You can download it from www.colorlightstudio.com.

Enjoy.

If you need any support, contact me through my site.

Igor Penjivrag.
www.colorlightstudio.com