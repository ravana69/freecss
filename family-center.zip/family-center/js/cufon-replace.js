Cufon.replace('h2', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('h3', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.logo', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.title-1', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.title-2', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.button', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.button2', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.menu > li > a', { fontFamily: 'Open Sans', hover:true });
Cufon.replace('.support-phone', { fontFamily: 'Open Sans', hover:true });
