
If you want the header without the old Greek guys...you can use top2.jpg instead of top.jpg :) 
And you can of course modify this header with what you want in photoshop...

Just change the name of the file in the css file (style.css)

David
http://www.free-css-templates.com