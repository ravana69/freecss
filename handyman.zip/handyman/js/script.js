$(document).ready(function() { 
	$(".list-services .tooltips").easyTooltip();
}); 