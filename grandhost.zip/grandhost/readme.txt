======================================================================
	Website Template Name: Free Business Website Template
	Website Template URI: http://www.templatemonster.com/free-templates/free-business-website-template.php
	Version: 1
	Author: TemplateMonster.com
	Author URI: http://www.templatemonster.com

======================================================================


	+++ Be sure to visit TemplateMonster.com for more website templates +++



	+++ License +++

	Free Business Website Template is 100% FREE! We kindly ask
	you to leave the footer links intact. That'd me much appreciated :)



	+++ INSTALLATION & EDITING +++

	- Copy all the files from the 'site' directory to the appropriate (usually 'www' or 'public_html') directory on your hosting. That's it.
	- This template may be edited with any HTML editor. If you do not know where to get one you may consider trying NotePad++. It can be downloaded at notepad-plus.sourceforge.net and it's free.



	+++ HOW TO PUT YOUR OWN LOGO +++

	- You need to replace logo.jpg (it is located in site>images>logo.jpg) with your own .gif or .jpeg file. It is recommended that you logo image should be 293X112 pixels.