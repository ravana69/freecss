// <![CDATA[
$(function() {
	// radius Box
	$('.box').css({"border-radius":"7px", "-moz-border-radius":"7px", "-webkit-border-radius":"7px"});
	
});
// ]]>