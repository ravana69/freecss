/* ====================================================

	Template Name: Canvas
	Description: A Responsive website template built 
	using HTML5, CSS3 and jQuery. Easy to customise
	and enhance. Uses Structured Data for better SEO.
	Author: Donny Burnside
	Author URI: http://www.donnyburnside.com
	Version: 1.0.0
	License: GNU General Public License v3.0
	License URI: http://www.gnu.org/licenses/gpl.html

	Canvas - A Free Website Template by Donny Burnside
	Copyright 2015 Donny Burnside
	Distributed under the terms of the GNU GPL

   ==================================================== */

/* ====================================================

	Q. How do I change the colour scheme?
	A. Include the specific colour from the /css/skins 
	folder in the usual way. Remove them completely
	to revert to the default "look".

   ==================================================== */