Project page:
http://digitalnature.ro/projects/arclite/

Licensed under GPL
http://www.opensource.org/licenses/gpl-license.php

