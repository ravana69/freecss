Cufon.replace('.menu a', { fontFamily: 'Kozuka Gothic Pro OpenType M', hover:true });
Cufon.replace('h2, h3, .text-2', { fontFamily: 'Kozuka Gothic Pro OpenType L', hover:true });
Cufon.replace('.text-1', { fontFamily: 'Kozuka Gothic Pro OpenType L', textShadow:'0 0 #7f7f7f', hover:true });