jQuery(document).ready(function() {
	jQuery('#mycarousel').jcarousel({    			
    	visible: 3    			
    });
}); 