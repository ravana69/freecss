EcolutionWarrior WordPress Theme
Created by ThemeWarrior - http://www.themewarrior.com
Support forum: http://forums.themewarrior.com

-----------------------------
INSTALLATION
-----------------------------

1. After you download the theme package, upload it to your theme folder located at /wp-content/themes/.

2. Login to your WordPress site as admin and go to Design -> Themes.

3. You'll see a list of theme installed on your WordPress site, choose EcolutionWarrior to activate it.

NOTES: In order to be able to show post thumbnail, you should create a custom field on your WordPress post named "thumb". If you don't have one the theme will display default post thumb image.

-----------------------------
LICENSE
-----------------------------

All the themes released by ThemeWarrior are licensed under Creative Commons 3.0. You may download all the themes for free but you have to keep the links and all copyright statement intact.

More information please visit http://www.themewarrior.com/page/license

YOU MAY NOT

1. Remove links to ThemeWarrior on all ThemeWarrior themes or templates.

2. Remove copyright statement on the theme.

MODIFICATIONS

You may modify all ThemeWarrior themes or templates licensed under Creative Commons, as long as the copyright statement and links to ThemeWarrior stay intact to the themes.

DISTRIBUTION

You may share all ThemeWarrior themes licensed under Creative Commons to anyone you like for free, as long as the copyright statement and links to ThemeWarrior stay intact to the themes.

For more information regarding the license go to http://www.themewarrior.com/page/license

-----------------------------
DONATION
-----------------------------

If you like this theme and want to support ThemeWarrior please kindly visit http://www.themewarrior.com/page/donate