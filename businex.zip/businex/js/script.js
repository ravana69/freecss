// <![CDATA[
$(function() {

  // Slider
  $('#coin-slider').coinslider({width:960,height:360,opacity:1});

  // Radius Box
  //$('a.com, a.rm, img.fl, .menu_nav ul, .menu_nav ul li a').css({"border-radius":"6px", "-moz-border-radius":"6px", "-webkit-border-radius":"6px"});
  //$('.header_resize').css({"border-top-left-radius":"16px", "border-top-right-radius":"16px", "-moz-border-radius-topleft":"16px", "-moz-border-radius-topright":"16px", "-webkit-border-top-left-radius":"16px", "-webkit-border-top-right-radius":"16px"});

});	

// Cufon
Cufon.replace('h1, h2, h3, h4, h5, h6', { hover: true });

// ]]>