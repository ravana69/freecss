======================================================================

	  Website Template Name: Architecture
	  Website Template URI: http://www.templatemonster.com/free-templates/free-architecture-website-template.php
	  Version: 1
	  Author: TemplateMonster.com Team
	  Author URI: http://www.templatemonster.com/

======================================================================


   +++ Be sure to visit TemplateMonster.com for more website templates +++


   +++ License +++

    Architecture website template is 100% FREE!  We kindly ask you to
   leave the footer links intact. Thank you so much! :)



   +++ INSTALLATION & EDITING +++

   - Copy all the files from the 'site' directory to the appropriate (usually 'www' or 'public_html') directory on your hosting. That's it.
   - This template may be edited with any HTML editor. If you do not know where to get one, you may consider trying NotePad++. It can be downloaded at notepad-plus.sourceforge.net and it's free.



   +++ HOW TO PUT YOUR OWN LOGO+++

   You need to replace logo.gif (it is located in site>images>logo.gif) with your own .gif file. It is recommended that your logo.gif should be 407 px x 70 px pixels.
