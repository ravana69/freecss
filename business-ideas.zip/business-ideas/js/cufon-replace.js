Cufon.replace('#content .aside ul li span, .txt1, h3', { fontFamily: 'Myriad Pro Light' });
Cufon.replace('#header .row-1 .fright ul li', { fontFamily: 'AvantGarde Bk BT', hover:true });