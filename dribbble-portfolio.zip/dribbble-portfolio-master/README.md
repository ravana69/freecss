dribbble-portfolio
==================

A simple 5 seconds set up Dribbble driven portfolio page

<a href="http://www.paolotripodi.com" target="_blank">Check out live demo here</a>

##Make it your own portfolio

- Replace <code>/img/profilepict.jpg</code> with your own profile picture
- Change the about text in <code>js/portfolio.js</code> and <code>index.html</code>
- Insert your Dribbble username in <code>js/portfolio.js</code> 
- Link the social icons in footer
- Enjoy 

##Resources

Dribble feeds provided using <a href="https://github.com/tylergaw/jribbble" target="_blank">Jribbble</a><br />
Based on <a href="getbootstrap.com" target="_blank">Bootstrap3</a><br />
Icons with <a href="http://graphicburger.com/simple-line-icons-webfont/" target="_blank">Simple Line Icons Webfont</a><br />
Styles written in <a href="http://sass-lang.com/" target="_blank">SCSS</a><br /> 

##Copyright and Licensing

Code and documentation © Paolo Tripodi, 2014. 
Code released under <a href="https://github.com/paolotripodi/Landy-v1.0/blob/master/LICENSE.md" alt="MIT Lincense">MIT</a>
