
You are free to use it as long as you keep the link to my website intact.
If you want to remove the link, you have to pay a small fee. Leave me a message using the
form at http://webdesignerlab.com/contact or email me at gratielad@gmail.com.
Enjoy!
Thanks!