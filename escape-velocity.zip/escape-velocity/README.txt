Escape Velocity 1.0 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

This is Escape Velocity, a fully responsive HTML5 site template designed by me (AJ) and
released for free by HTML5 UP. It features a minimalistic design, spacious layout, and
styling for all basic page elements (including blockquotes, tables and lists).

Escape Velocity's incredible demo images* are courtesy of the supremely talented photographer
Felicia Simion. If you like photography or just enjoy being blown away by awesome stuff, check
out her portfolio for more stunning images:

http://ineedchemicalx.deviantart.com/

* Not included with this download (replaced with generic placeholders). Note that I only
have permission to use her images in my on-site demos, so do NOT download and use any of
Felicia's work without her explicit permission.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

- AJ (@n33co)

PS: This site template is fully responsive, meaning it'll look great on desktop 
(widescreen and standard), tablet and mobile device displays. To see what this looks
like, just narrow down your browser window and hit "reload".

Credits:
	
	Demo Images:
		Felicia Simion (http://ineedchemicalx.deviantart.com/)
	
	Icons:
		Font Awesome (http://fortawesome.github.com/Font-Awesome/)
		Font Awesome More (http://gregoryloucas.github.com/Font-Awesome-More/)