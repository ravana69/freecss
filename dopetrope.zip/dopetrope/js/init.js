_5grid.ready(function() {

	if (_5grid.isDesktop)
	{
		$('#nav > ul').dropotron({ 
			offsetY: -17,
			offsetX: -1,
			mode: 'fade',
			noOpenerFade: true
		});
	}

});