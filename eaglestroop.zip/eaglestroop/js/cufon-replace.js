Cufon.replace('h2, h3, .title-1, .text-1', { fontFamily: 'Glegoo', hover:true });
Cufon.replace('.button', { fontFamily: 'Glegoo', textShadow: "1px 1px rgba(255, 255, 255, 0.9)", hover:true });
Cufon.replace('.button2', { fontFamily: 'Glegoo', textShadow: "1px 1px rgba(0, 0, 0, 0.2)", hover:true });
