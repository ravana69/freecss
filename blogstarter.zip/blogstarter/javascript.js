var imgLoading = 'assets/images/lightbox/loading.gif';
var imgClose = 'assets/images/lightbox/closelabel.gif';

var videoWidth = 300;
var videoHeight = 225;
var youtubeID = 'FpAgUMUlhw4';

var searchDefault = '';
var searchColor = '#000000';
