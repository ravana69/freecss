$(function(){ 							   

	// radiys box
	$('.menu_nav ul li a').css({"border-radius": "10px", "-moz-border-radius":"10px", "-webkit-border-radius":"10px"});
	$('.hbg').css({"border-radius": "0 20px 20px 0", "-moz-border-radius":"0 20px 20px 0", "-webkit-border-radius":"0 20px 20px 0"});
	$('.fbg').css({"border-radius": "20px", "-moz-border-radius":"20px", "-webkit-border-radius":"20px"});
	$('.pagenavi a, .pagenavi .current').css({"border-radius": "5px", "-moz-border-radius":"5px", "-webkit-border-radius":"5px"});
	$('a.rm, a.com').css({"border-radius": "5px", "-moz-border-radius":"5px", "-webkit-border-radius":"5px"});
	
});	