Cufon.replace('.title-1, .title-2, .title-3, h3, .numb ', { fontFamily: 'Asap', hover:true });
Cufon.replace('h1 a', { fontFamily: 'Asap italic', hover:true });
